##################################
#Running 
##################################

#generate input files for PLINK
plink --vcf clean_BIALLELIC.VCF --maf 0.01 --recode --out hla --const-fid 0 --make-bed 

#add sex as covariate
plink --bfile hla --update-sex sex.phe --make-bed -out hla_sex

#run ligistic regression using age as covariate
plink --bfile hla_sex --pheno phenotype.phe --all-pheno --linear -out hla -covar age.phe

#run ligistic regression using age as covariate + correcting for multiple sample comparison 
plink --bfile hla_sex --pheno phenotype.phe --all-pheno --linear -out hla -covar age.phe --adjust 


#check linkage disequilibrium
plink --bfile hla_sex --r2

